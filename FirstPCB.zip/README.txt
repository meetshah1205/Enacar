This is a PCB design for Enacar.

The files for the schematic, PCB, ERC + DRC reports are given.

Some warnings in the DRC file are to be ignored as they are mainly silkscreen overlap warnings.

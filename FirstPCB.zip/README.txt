ENACAR – Motor Driver (Arduino Powered)
=======================================

This is ENACAR’s custom motor driver board, designed by Meet Shah.
It’s powered by the L298N H-Bridge IC, capable of driving two DC motors
with full control from an Arduino.

------------------------------------------------------------
FEATURES
------------------------------------------------------------
- Dual DC motor driver.
- Screw terminals for easy motor and power connections.
- Pin header (J5) for direct Arduino control:
    ENA, IN1, IN2 -> Motor A
    ENB, IN3, IN4 -> Motor B
- External power input (up to 9V) with filtering capacitors.
- On-board LED for quick power indication.
- Ground pour for stability and reduced noise.
- Thick copper traces for motor current.
- Clear silkscreen labels for all connections.
- Custom artwork:
    -> Childhood me in Studio Ghibli style.
    -> ENACAR mascot cat.

------------------------------------------------------------
HOW TO USE
------------------------------------------------------------
1. Connect a 7–9V supply to the Power screw terminal.
2. Attach Motor A and Motor B to their screw terminals.
3. Hook up Arduino pins to J5 header:
      Pin 1 -> ENA
      Pin 2 -> IN1
      Pin 3 -> IN2
      Pin 4 -> ENB
      Pin 5 -> IN3
      Pin 6 -> IN4
4. Upload your motor control code to Arduino.
5. Enjoy smooth motor control.

------------------------------------------------------------
NOTES
------------------------------------------------------------
- Double-check polarity on power terminals (+9V / GND).
- Motors can draw high current. Use fresh batteries or a stable supply.
- First PCBs are for learning. If this fails, it's your fault for trying
